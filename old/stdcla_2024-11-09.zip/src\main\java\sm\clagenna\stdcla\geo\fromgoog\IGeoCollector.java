package sm.clagenna.stdcla.geo.fromgoog;

import sm.clagenna.stdcla.geo.GeoCoord;

public interface IGeoCollector {
  void add(GeoCoord coo);
}
