package sm.clagenna.stdcla.geo.fromgoog;

public interface IGoogleTrack {
  void gestTrack(String p_pth, Object val);
}
