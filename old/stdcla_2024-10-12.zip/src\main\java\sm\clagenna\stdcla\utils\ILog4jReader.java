package sm.clagenna.stdcla.utils;

public interface ILog4jReader {
  void addLog(String [] arr);
}
