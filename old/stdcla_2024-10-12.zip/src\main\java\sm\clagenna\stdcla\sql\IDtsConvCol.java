package sm.clagenna.stdcla.sql;

@FunctionalInterface
public interface IDtsConvCol<T> {
  
   T converti(T o);

}
