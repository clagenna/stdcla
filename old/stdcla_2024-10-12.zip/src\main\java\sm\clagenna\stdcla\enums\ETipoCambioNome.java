package sm.clagenna.stdcla.enums;

public enum ETipoCambioNome {

  piu1Minuto, //
  piu1Secondo, //
  conSuffisso

}
