package sm.clagenna.stdcla.geo;

public enum EGeoSrcCoord {
  track,//
  google, //
  foto;
}
